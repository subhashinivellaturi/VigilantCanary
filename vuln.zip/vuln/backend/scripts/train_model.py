from __future__ import annotations

from pathlib import Path

import joblib

from app.services.trainer import VulnerabilityTrainer


def main() -> None:
    trainer = VulnerabilityTrainer()
    artifact = trainer.train()
    model_dir = Path(__file__).resolve().parent.parent / "artifacts"
    model_dir.mkdir(exist_ok=True)
    joblib.dump(artifact.pipeline, model_dir / "pipeline.joblib")
    print(f"Saved pipeline with {artifact.dataset_size} rows")


if __name__ == "__main__":
    main()
