declare module '@storybook/react';
